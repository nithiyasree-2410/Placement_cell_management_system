# PlaceTrack – Placement Cell Management System

## Quick Start

```bash
mvn spring-boot:run
# OR
./mvnw spring-boot:run
```

App runs at **http://localhost:8080**

### Default Login Credentials

| Role      | Email                      | Password       | Company     |
|-----------|----------------------------|----------------|-------------|
| Admin     | admin@placement.com        | admin123       | —           |
| Student   | student@placement.com      | student123     | —           |
| Recruiter | recruiter@placement.com    | recruiter123   | TCS only    |

---

## Architecture

- **Backend**: Spring Boot 3 + Spring Security + Spring Data JPA
- **Database**: H2 (file-based, persists in `./data/` folder)
- **Frontend**: Thymeleaf + custom CSS
- **Auth**: Spring Security session-based (BCrypt password encoding)

---

## Recent Changes (v2 – Security & Edit Update)

### 1. Recruiter Access Restriction (Backend-Enforced)

**Files changed:**
- `User.java` – Added `company_id` FK column linking recruiter → Company
- `RecruiterController.java` – `getRecruiterCompany(auth)` helper extracts the
  logged-in recruiter's company from their session; all queries are scoped to it
- `RecruiterController.java` – `assertJobBelongsToCompany()` throws on unauthorized access
- `ApplicationRepository.java` – Added `findByJobPosting_Company()` JPQL query
- `JobPostingRepository.java` – Added `findByCompany*` methods
- `ApplicationService.java` – Added `getApplicationsByCompany()` and `countApplicationsByCompany()`
- `JobPostingService.java` – Added `getJobsByCompany()` and `getActiveJobsByCompany()`
- `DataInitializer.java` – Demo recruiter is now linked to TCS company

**Result:** A recruiter can only see jobs and applications belonging to their own company.
Attempting to access another company's job via direct URL returns a 500 (RuntimeException).

### 2. Job Edit Functionality

**Files changed / created:**
- `RecruiterController.java` – GET `/recruiter/jobs/{id}/edit` (load form with pre-filled values)
- `RecruiterController.java` – POST `/recruiter/jobs/{id}/edit` (save changes)
- `templates/recruiter/edit-job.html` – New edit form with all fields, CSRF token, validation
- `templates/recruiter/jobs.html` – Added Edit button per row
- `templates/recruiter/dashboard.html` – Added Edit button in recent jobs table
- `templates/recruiter/applications.html` – Added Edit Job button in header

**Fields editable:** Job Title, Job Description, Required Skills, Package (LPA),
Location, Application Deadline, Min CGPA, Department Eligible, Vacancies, Job Type, Status

### 3. Database Fixes

**Files changed:**
- `Application.java` – Added `@UniqueConstraint` on `(student_id, job_posting_id)` to
  prevent duplicate applications at the DB level
- `ApplicationService.java` – Added service-layer duplicate check (throws `RuntimeException`)
- `StudentController.java` – Wrapped apply in try/catch; shows error message on duplicate
- `application.properties` – Switched from `create-drop` (wiped on restart) to
  `file-based H2 + ddl-auto=update` (data persists across restarts)
- `database_setup.sql` – Added `company_id` column to users table; added unique constraint
  and index on applications; reordered table creation to respect FK dependencies

### 4. UI Updates

**Files changed:**
- `templates/recruiter/dashboard.html` – Shows company-scoped stats (not global)
- `templates/recruiter/applications.html` – Added department column, job summary card, CSRF
- `templates/recruiter/jobs.html` – Shows count badge, company name in header
- All recruiter pages show logged-in company name in sidebar and page titles

---

## Adding a New Recruiter (Admin Task)

1. Log in as Admin
2. Create a new user with role RECRUITER
3. Use the database console (`/h2-console`) or add an admin UI endpoint to set `company_id`
   on the user record

---

## H2 Database Console

URL: http://localhost:8080/h2-console  
JDBC URL: `jdbc:h2:file:./data/placementdb`  
Username: `sa`  Password: *(empty)*
