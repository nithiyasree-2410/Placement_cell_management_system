package com.placement.controller;

import com.placement.model.*;
import com.placement.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/recruiter")
public class RecruiterController {

    @Autowired private JobPostingService jobPostingService;
    @Autowired private ApplicationService applicationService;
    @Autowired private CompanyService companyService;
    @Autowired private UserService userService;

    // -----------------------------------------------------------------------
    // Helper: resolve the logged-in recruiter's company (mandatory)
    // -----------------------------------------------------------------------
    private Company getRecruiterCompany(Authentication auth) {
        String email = auth.getName();
        User user = userService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Authenticated user not found: " + email));
        if (user.getRole() != User.Role.RECRUITER) {
            throw new RuntimeException("Access denied: not a recruiter account.");
        }
        if (user.getCompany() == null) {
            throw new RuntimeException(
                    "Recruiter account is not linked to any company. Please contact the admin.");
        }
        return user.getCompany();
    }

    // -----------------------------------------------------------------------
    // Helper: verify a job belongs to the recruiter's company (security gate)
    // -----------------------------------------------------------------------
    private void assertJobBelongsToCompany(JobPosting job, Company company) {
        if (!job.getCompany().getId().equals(company.getId())) {
            throw new RuntimeException(
                    "Access denied: this job does not belong to your company.");
        }
    }

    // -----------------------------------------------------------------------
    // Dashboard
    // -----------------------------------------------------------------------
    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication auth) {
        Company company = getRecruiterCompany(auth);
        List<JobPosting> companyJobs = jobPostingService.getJobsByCompany(company);
        long activeJobCount = companyJobs.stream()
                .filter(j -> j.getStatus() == JobPosting.JobStatus.ACTIVE).count();
        long totalApplications = applicationService.countApplicationsByCompany(company);

        model.addAttribute("company", company);
        model.addAttribute("activeJobCount", activeJobCount);
        model.addAttribute("totalApplications", totalApplications);
        model.addAttribute("recentJobs",
                companyJobs.stream().limit(5).toList());
        model.addAttribute("recruiterName", auth.getName());
        return "recruiter/dashboard";
    }

    // -----------------------------------------------------------------------
    // Job Postings – list (company-scoped)
    // -----------------------------------------------------------------------
    @GetMapping("/jobs")
    public String listJobs(Model model, Authentication auth) {
        Company company = getRecruiterCompany(auth);
        model.addAttribute("jobs", jobPostingService.getJobsByCompany(company));
        model.addAttribute("company", company);
        return "recruiter/jobs";
    }

    // -----------------------------------------------------------------------
    // Applications for a job – view (security-checked)
    // -----------------------------------------------------------------------
    @GetMapping("/jobs/{id}/applications")
    public String viewApplications(@PathVariable Long id, Model model, Authentication auth) {
        Company company = getRecruiterCompany(auth);
        JobPosting job = jobPostingService.getJobPostingById(id)
                .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        // Security: job must belong to recruiter's company
        assertJobBelongsToCompany(job, company);
        model.addAttribute("job", job);
        model.addAttribute("applications", applicationService.getApplicationsByJob(job));
        model.addAttribute("company", company);
        return "recruiter/applications";
    }

    // -----------------------------------------------------------------------
    // Update application status (security-checked)
    // -----------------------------------------------------------------------
    @PostMapping("/applications/{id}/status")
    public String updateStatus(@PathVariable Long id,
                               @RequestParam String status,
                               @RequestParam(required = false) Long jobId,
                               Authentication auth,
                               RedirectAttributes ra) {
        Company company = getRecruiterCompany(auth);
        Application app = applicationService.getApplicationById(id)
                .orElseThrow(() -> new RuntimeException("Application not found: " + id));
        // Security: application's job must belong to recruiter's company
        assertJobBelongsToCompany(app.getJobPosting(), company);

        try {
            app.setStatus(Application.ApplicationStatus.valueOf(status));
            applicationService.saveApplication(app);
            ra.addFlashAttribute("successMessage", "Application status updated successfully!");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("errorMessage", "Invalid status value: " + status);
        }

        if (jobId != null) {
            return "redirect:/recruiter/jobs/" + jobId + "/applications";
        }
        return "redirect:/recruiter/dashboard";
    }

    // -----------------------------------------------------------------------
    // Edit Job – show form (security-checked, values pre-filled)
    // -----------------------------------------------------------------------
    @GetMapping("/jobs/{id}/edit")
    public String editJobForm(@PathVariable Long id, Model model, Authentication auth) {
        Company company = getRecruiterCompany(auth);
        JobPosting job = jobPostingService.getJobPostingById(id)
                .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        assertJobBelongsToCompany(job, company);
        model.addAttribute("job", job);
        model.addAttribute("company", company);
        return "recruiter/edit-job";
    }

    // -----------------------------------------------------------------------
    // Edit Job – handle POST (security-checked)
    // -----------------------------------------------------------------------
    @PostMapping("/jobs/{id}/edit")
    public String updateJob(@PathVariable Long id,
                            @RequestParam String jobTitle,
                            @RequestParam(required = false) String jobDescription,
                            @RequestParam(required = false) String requiredSkills,
                            @RequestParam(required = false) Double packageLpa,
                            @RequestParam(required = false) String location,
                            @RequestParam(required = false) String applicationDeadline,
                            @RequestParam(required = false) Double minCgpa,
                            @RequestParam(required = false) String departmentEligible,
                            @RequestParam(required = false) Integer vacancies,
                            @RequestParam(required = false) String jobType,
                            @RequestParam(required = false) String status,
                            Authentication auth,
                            RedirectAttributes ra) {
        Company company = getRecruiterCompany(auth);
        JobPosting job = jobPostingService.getJobPostingById(id)
                .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        assertJobBelongsToCompany(job, company);

        // Validate required field
        if (jobTitle == null || jobTitle.isBlank()) {
            ra.addFlashAttribute("errorMessage", "Job title is required.");
            return "redirect:/recruiter/jobs/" + id + "/edit";
        }

        try {
            job.setJobTitle(jobTitle.trim());
            if (jobDescription != null) job.setJobDescription(jobDescription.trim());
            if (requiredSkills != null) job.setRequiredSkills(requiredSkills.trim());
            if (packageLpa != null) job.setPackageLpa(packageLpa);
            if (location != null && !location.isBlank()) job.setLocation(location.trim());
            if (applicationDeadline != null && !applicationDeadline.isBlank())
                job.setApplicationDeadline(LocalDate.parse(applicationDeadline));
            if (minCgpa != null) job.setMinCgpa(minCgpa);
            if (departmentEligible != null) job.setDepartmentEligible(departmentEligible.trim());
            if (vacancies != null) job.setVacancies(vacancies);
            if (jobType != null && !jobType.isBlank()) job.setJobType(jobType.trim());
            if (status != null && !status.isBlank())
                job.setStatus(JobPosting.JobStatus.valueOf(status));

            jobPostingService.saveJobPosting(job);
            ra.addFlashAttribute("successMessage",
                    "Job posting \"" + job.getJobTitle() + "\" updated successfully!");
        } catch (Exception e) {
            ra.addFlashAttribute("errorMessage", "Error updating job: " + e.getMessage());
            return "redirect:/recruiter/jobs/" + id + "/edit";
        }

        return "redirect:/recruiter/jobs";
    }
}
