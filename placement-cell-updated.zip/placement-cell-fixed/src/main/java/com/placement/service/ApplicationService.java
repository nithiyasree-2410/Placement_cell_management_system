package com.placement.service;

import com.placement.model.Application;
import com.placement.model.Company;
import com.placement.model.JobPosting;
import com.placement.model.Student;
import com.placement.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    public List<Application> getApplicationsByStudent(Student student) {
        return applicationRepository.findByStudent(student);
    }

    public List<Application> getApplicationsByJob(JobPosting jobPosting) {
        return applicationRepository.findByJobPosting(jobPosting);
    }

    /**
     * Returns ONLY applications for jobs posted by the given company.
     * Used in recruiter views to enforce data isolation.
     */
    public List<Application> getApplicationsByCompany(Company company) {
        return applicationRepository.findByJobPosting_Company(company);
    }

    public Optional<Application> getApplicationById(Long id) {
        return applicationRepository.findById(id);
    }

    public boolean hasApplied(Student student, JobPosting jobPosting) {
        return applicationRepository.existsByStudentAndJobPosting(student, jobPosting);
    }

    public Application saveApplication(Application application) {
        // Prevent duplicate applications at service level
        if (application.getId() == null &&
                applicationRepository.existsByStudentAndJobPosting(
                        application.getStudent(), application.getJobPosting())) {
            throw new RuntimeException("You have already applied for this job.");
        }
        return applicationRepository.save(application);
    }

    public void deleteApplication(Long id) {
        applicationRepository.deleteById(id);
    }

    public long countByStatus(Application.ApplicationStatus status) {
        return applicationRepository.countByStatus(status);
    }

    public long countAllApplications() {
        return applicationRepository.count();
    }

    public long countApplicationsByCompany(Company company) {
        return applicationRepository.countByJobPosting_Company(company);
    }
}
