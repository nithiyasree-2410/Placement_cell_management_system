package com.placement.service;

import com.placement.model.Company;
import com.placement.model.JobPosting;
import com.placement.repository.JobPostingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

    public List<JobPosting> getAllJobPostings() {
        return jobPostingRepository.findAll();
    }

    public List<JobPosting> getActiveJobPostings() {
        return jobPostingRepository.findByStatus(JobPosting.JobStatus.ACTIVE);
    }

    /** Returns all jobs posted by a specific company (for recruiter views). */
    public List<JobPosting> getJobsByCompany(Company company) {
        return jobPostingRepository.findByCompany(company);
    }

    /** Returns only active jobs for a company. */
    public List<JobPosting> getActiveJobsByCompany(Company company) {
        return jobPostingRepository.findByCompanyAndStatus(company, JobPosting.JobStatus.ACTIVE);
    }

    public Optional<JobPosting> getJobPostingById(Long id) {
        return jobPostingRepository.findById(id);
    }

    public JobPosting saveJobPosting(JobPosting jobPosting) {
        return jobPostingRepository.save(jobPosting);
    }

    public void deleteJobPosting(Long id) {
        jobPostingRepository.deleteById(id);
    }

    public long countActiveJobs() {
        return jobPostingRepository.countByStatus(JobPosting.JobStatus.ACTIVE);
    }

    public long countJobsByCompany(Company company) {
        return jobPostingRepository.countByCompany(company);
    }

    public long countActiveJobsByCompany(Company company) {
        return jobPostingRepository.countByCompanyAndStatus(company, JobPosting.JobStatus.ACTIVE);
    }
}
