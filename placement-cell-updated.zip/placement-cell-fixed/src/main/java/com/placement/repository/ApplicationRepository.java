package com.placement.repository;

import com.placement.model.Application;
import com.placement.model.Company;
import com.placement.model.JobPosting;
import com.placement.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByStudent(Student student);
    List<Application> findByJobPosting(JobPosting jobPosting);
    Optional<Application> findByStudentAndJobPosting(Student student, JobPosting jobPosting);
    boolean existsByStudentAndJobPosting(Student student, JobPosting jobPosting);
    long countByStatus(Application.ApplicationStatus status);

    /**
     * Returns only applications for jobs belonging to the given company.
     * Used by recruiters to see only their company's applicants.
     */
    @Query("SELECT a FROM Application a WHERE a.jobPosting.company = :company")
    List<Application> findByJobPosting_Company(@Param("company") Company company);

    /**
     * Count applications for jobs of a given company.
     */
    @Query("SELECT COUNT(a) FROM Application a WHERE a.jobPosting.company = :company")
    long countByJobPosting_Company(@Param("company") Company company);
}
